﻿using System;
using System.Collections.Generic;

namespace Recruit.WebAPI.Models
{
    public partial class TReclutador
    {
        public int Pkreclutador { get; set; }
        public string Nombrereclutador { get; set; }
        public string Telefonoreclutador { get; set; }
        public string Correoreclutador { get; set; }
        public int? Estadoreclutador { get; set; }
    }
}
