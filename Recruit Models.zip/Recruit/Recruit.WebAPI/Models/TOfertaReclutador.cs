﻿using System;
using System.Collections.Generic;

namespace Recruit.WebAPI.Models
{
    public partial class TOfertaReclutador
    {
        public int Pkofertatrabajo { get; set; }
        public int Pkreclutador { get; set; }
    }
}
